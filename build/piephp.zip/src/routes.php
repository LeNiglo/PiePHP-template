<?php

use PiePHP\Core\Router;

Router::connect('/', ['c' => 'welcome', 'a' => 'index']);
